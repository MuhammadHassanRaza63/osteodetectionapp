import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib import colors
from io import BytesIO
from django.conf import settings
import os
from datetime import datetime
from PIL import Image

def is_valid_xray(image_path):
    """
    Validate if the image is a valid X-ray based on format, dimensions, and basic properties.
    Returns (is_valid, error_message).
    """
    try:
        valid_extensions = ['.jpg', '.jpeg', '.png']
        if not any(image_path.lower().endswith(ext) for ext in valid_extensions):
            return False, "Invalid file format. Please upload a .jpg, .jpeg, or .png image."

        img = Image.open(image_path)
        width, height = img.size
        if width < 224 or height < 224:
            return False, "Image is too small. Please upload an image with at least 224x224 pixels."

        img_gray = img.convert('L')
        img_array = np.array(img_gray)
        intensity_range = np.max(img_array) - np.min(img_array)
        if intensity_range < 50:
            return False, "Image does not resemble an X-ray. Please upload a valid X-ray image."

        return True, None
    except Exception as e:
        return False, f"Error processing image: {str(e)}"

def predict_image(image_path):
    """
    Predict the class of the X-ray image and check for irrelevant images.
    Returns (predicted_class, confidence, is_relevant, error_message).
    """
    is_valid, error_message = is_valid_xray(image_path)
    if not is_valid:
        return None, None, False, error_message

    model = load_model(os.path.join(settings.BASE_DIR, 'model/model.h5'))
    img = load_img(image_path, target_size=(224, 224))
    img_array = img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    prediction = model.predict(img_array)[0]
    classes = ['Normal', 'Osteopenia', 'Osteoporosis']
    predicted_class = classes[np.argmax(prediction)]
    confidence = float(np.max(prediction)) * 100

    CONFIDENCE_THRESHOLD = 70.0
    if confidence < CONFIDENCE_THRESHOLD:
        return None, None, False, "Image appears irrelevant. Please upload a valid X-ray image."

    return predicted_class, confidence, True, None

def generate_pdf_report(image_path, result, confidence):
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 24)
    c.drawString(1 * inch, 10 * inch, "OsteoDetect")
    c.setFont("Helvetica", 16)
    c.drawString(1 * inch, 9.5 * inch, "Osteoporosis Detection Report")
    c.setFont("Helvetica", 12)
    c.drawString(1 * inch, 9 * inch, f"Date: {settings.TIME_ZONE} - {datetime.now()}")
    c.drawString(1 * inch, 8.5 * inch, f"Result: {result}")
    c.drawString(1 * inch, 8 * inch, f"Confidence: {confidence:.2f}%")
    c.drawImage(image_path, 1 * inch, 4 * inch, width=3 * inch, height=3 * inch)
    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer