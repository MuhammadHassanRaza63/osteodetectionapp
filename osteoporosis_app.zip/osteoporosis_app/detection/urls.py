from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('result/<int:xray_id>/', views.result, name='result'),
    path('download_pdf/<int:xray_id>/', views.download_pdf, name='download_pdf'),
]