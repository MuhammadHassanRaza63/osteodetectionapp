from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import XRayImage
from .utils import predict_image, generate_pdf_report
import os

def home(request):
    error_message = None
    if request.method == 'POST':
        if 'xray_image' in request.FILES:
            image = request.FILES['xray_image']
            xray = XRayImage.objects.create(image=image)
            result, confidence, is_relevant, error = predict_image(xray.image.path)
            if is_relevant:
                xray.result = result
                xray.confidence = confidence
                xray.save()
                return redirect('result', xray_id=xray.id)
            else:
                error_message = error
                xray.delete()
        else:
            error_message = "No image uploaded. Please select an image."
    return render(request, 'home.html', {'error_message': error_message})

def result(request, xray_id=None):
    xray = XRayImage.objects.get(id=xray_id) if xray_id else None
    return render(request, 'result.html', {'xray': xray})

def download_pdf(request, xray_id):
    xray = XRayImage.objects.get(id=xray_id)
    buffer = generate_pdf_report(xray.image.path, xray.result, xray.confidence)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="osteoporosis_report_{xray_id}.pdf"'
    return response